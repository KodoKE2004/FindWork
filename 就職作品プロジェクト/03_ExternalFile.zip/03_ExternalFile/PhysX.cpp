#include "PhysX.h"
using namespace PhysxVariable;

void PhysxVariable::FreeFall(float time, float3& vec)
{
	vec.y += -0.5f * G * time;
}

void PhysxVariable::ConstantMove(float setX, float setY, float setZ, float3& vec)
{
	vec.x += setX;
	vec.y += setY;
	vec.z += setZ;
}

void PhysxVariable::AddForce(float setX, float setY, float setZ, float3& vec)
{
	vec.x += setX;
	vec.y += setY;
	vec.z += setZ;
}
